import { Component, OnInit } from '@angular/core';
import { CarroService } from '../services/carro.service';
import { IItem } from '../interfaces/item.interface';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  usuario!:string;

  constructor(private router: Router){}

  ngOnInit(): void {
     this.usuario = localStorage.getItem('usuarioActual');
      console.log(this.usuario);
  }

  title = 'shopping-cart';

  public openCart:boolean = false;
  public cantProducts:number = 0;

  public cart(){
    this.openCart = !this.openCart;
  }


}
