import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  cUser='Adonis';
  cPwd='adonis';
  alertUser!:string;
  validador!:boolean;

  constructor(private router: Router) { }

  user = new FormControl('');
  pwd = new FormControl('');

  ngOnInit(): void {
  }

  validar(){
    
    if(this.user.value == this.cUser){
      this.alertUser='';
      this.validador=true;
    }else{
      this.alertUser='Usuario o  password incorrecto'
      this.validador=false;
    }
    if(this.pwd.value == this.cPwd){
      this.alertUser='';
      this.validador=true;
    }else{
      this.alertUser='Usuario o  password incorrecto'
      this.validador=false;
    }
    if(this.validador==true){
      Swal.fire('Bien!',`${this.user.value} Has iniciado sesión Correctamente!`,'success');
      this.router.navigate(['inicio']);
      localStorage.setItem('usuarioActual',this.user.value);
    }
  }

}
