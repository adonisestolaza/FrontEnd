import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CarroService } from '../services/carro.service';
import { IItem } from '../interfaces/item.interface';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cart',
  templateUrl: './carro.component.html',
  styleUrls: ['./carro.component.scss']
})
export class CarroComponent implements OnInit {

  public items: Array<IItem>
  public totalPrecio:number = 0;
  public totalItems:number = 0;

  usuario:string;
  constructor(private carroService:CarroService) { }

  ngOnInit() {
    this.carroService.datosActualesCarro.subscribe(p =>{
      if(p)
      {
        this.items = p;
        this.totalItems = p.length;
        this.totalPrecio = p.reduce((sum, pr) => sum + (pr.precio * pr.cantidad), 0);
      }
    })
    this.usuario = localStorage.getItem('usuarioActual');
  }


  public remove(producto:IItem)
  {
    Swal.fire('Eliminado!',`El producto ${producto.nombre} fue eliminado con exito!`, 'warning')
    this.carroService.quitarElemento(producto);
  }
  

}
