export interface IItem {

    id:number,
    img:string,
    nombre:string,
    descripcion:string,
    precio:number,
    cantidad:number,
    tags:string

}
