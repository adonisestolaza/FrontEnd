import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductoComponent } from './productos/producto.component';
import { InicioComponent } from './inicio/inicio.component';
import { PagarComponent } from './pagar/pagar.component';
import { CarroComponent } from './carro/carro.component';
import { LoginComponent } from './login/login.component';
import { BoletaComponent } from './boleta/boleta.component';


const routes: Routes = [
  {path: "", pathMatch: 'full', redirectTo:'login'},
  {path: 'productos', component: ProductoComponent},
  {path: 'inicio', component: InicioComponent},
  {path: 'pagar', component: PagarComponent},
  {path: 'carro', component: CarroComponent},
  {path: 'login', component: LoginComponent},
  {path: 'boleta', component: BoletaComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
