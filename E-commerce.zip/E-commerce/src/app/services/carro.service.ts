import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IItem } from '../interfaces/item.interface';

@Injectable({
  providedIn: 'root'
})
export class CarroService {

  private carro = new BehaviorSubject<Array<IItem>>(null);
  public datosActualesCarro = this.carro.asObservable();

  pago:any[]=[];

  constructor() { }

  public cargarCarro(nuevoProducto: IItem) {
    //Obtenemos el valor actual
    let listaCarro = this.carro.getValue();
    //Si no es el primer item del carrito
    if(listaCarro)
    {
      //Buscamos si ya cargamos ese item en el carrito
      let objIndex = listaCarro.findIndex((obj => obj.id == nuevoProducto.id));
      //Si ya cargamos uno aumentamos su cantidad
      if(objIndex != -1)
      {
        listaCarro[objIndex].cantidad += 1;
      }
      //Si es el primer item de ese tipo lo agregamos derecho al carrito
      else {
        listaCarro.push(nuevoProducto);
      }  
    }
    //Si es el primer elemento lo inicializamos
    else {
      listaCarro = [];
      listaCarro.push(nuevoProducto);
    }

    this.carro.next(listaCarro);
  }

  public quitarElemento(nuevoProducto:IItem){
    //Obtenemos el valor actual de carrito
    let listaCarro = this.carro.getValue();
    //Buscamos el item del carrito para eliminar
    let objIndex = listaCarro.findIndex((obj => obj.id == nuevoProducto.id));
    if(objIndex != -1)
    {
      //Seteamos la cantidad en 1 (ya que los array se modifican los valores por referencia, si vovlemos a agregarlo la cantidad no se reiniciará)
      listaCarro[objIndex].cantidad = 1;

      //Eliminamos el item del array del carrito
      listaCarro.splice(objIndex,1);
    }

    this.carro.next(listaCarro);

  }

  public generarPago(datos:any){
    this.pago.push(datos);
  }


}
