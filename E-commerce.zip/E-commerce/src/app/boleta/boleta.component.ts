import { Component, OnInit } from '@angular/core';
import { CarroService } from '../services/carro.service';
import { IItem } from '../interfaces/item.interface';

@Component({
  selector: 'app-boleta',
  templateUrl: './boleta.component.html',
  styleUrls: ['./boleta.component.css']
})
export class BoletaComponent implements OnInit {

  pagos:any[]= [];
  items:any[]=[];
  totalCantidad:number;
  totalPrecio:number;
  numBoleta:number;
  fecha:string;

  constructor(private carroService: CarroService) { }

  ngOnInit(): void {
    this.pagos = this.carroService.pago;
    console.log(this.pagos);

    this.carroService.datosActualesCarro.subscribe(p =>{
      if(p)
      {
        this.items = p;
        this.totalCantidad = p.length;
        this.totalPrecio = p.reduce((sum, pr) => sum + (pr.precio * pr.cantidad), 0);

      }
    });
  

    this.numBoleta = Math.round(Math.random()* (100 - 10)+ 10);
    this.fecha = Date();

  }

  vaciarCarro(){
    this.carroService.datosActualesCarro.subscribe(p =>{
      p.splice(0,p.length);
    });
  }


}
