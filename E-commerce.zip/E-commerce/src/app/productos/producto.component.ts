import { Component, OnInit } from '@angular/core';
import { IItem } from '../interfaces/item.interface';
import { CarroService } from '../services/carro.service';
import Swal from 'sweetalert2'
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './producto.component.html',
  styleUrls: ['./producto.component.css']
})
export class ProductoComponent implements OnInit {

  page:number;
  clave = new FormControl('');
  usuario:string;


  public listarProductos:Array<IItem> = [{
    id: 1,
    img: "assets/img/goose.png",
    nombre: "Goosse Island",
    precio: 2500,
    descripcion: "",
    cantidad : 1,
    tags : "ale"
  },
  {
    id: 2,
    img: "assets/img/heineken.png",
    nombre: "Heineken",
    precio: 1500,
    descripcion: "",
    cantidad : 1,
    tags : "pale"
  },
  {
    id: 3,
    img: "assets/img/paulaner.png",
    nombre: "Paulaner",
    precio: 2500,
    descripcion: "",
    cantidad : 1,
    tags : "weisbier"
  },
  {
    id: 4,
    img: "assets/img/becker.png",
    nombre: "Pack 4 Becker",
    precio: 5500,
    descripcion: "",
    cantidad : 1,
    tags : "lager"
  },
  {
    id: 5,
    img: "assets/img/frank.png",
    nombre: "Pack 10 Cervezas Franziskaner + Vaso 500cc",
    precio: 11500,
    descripcion: "",
    cantidad : 1,
    tags : "weisbier"
  },
  {
    id: 6,
    img: "assets/img/quilmes.png",
    nombre: "Pack 12 Cervezas Quilmes Botella 340ml",
    precio: 5500,
    descripcion: "",
    cantidad : 1,
    tags : "lager"
  },
  {
    id: 7,
    img: "assets/img/archor.png",
    nombre: "Anchor Fog Breaker IPA Botella 355ml",
    precio: 2300,
    descripcion: "",
    cantidad : 1,
    tags : "ale"
  },
  {
    id: 8,
    img: "assets/img/cuello.png",
    nombre: "Pack de Degustación 12 Cervezas Cuello Negro",
    precio: 25000,
    descripcion: "",
    cantidad : 1,
    tags : "ambar"
  },
  {
    id: 9,
    img: "assets/img/tubinger.png",
    nombre: "Cerveza Tübinger IPA Botella 330ml",
    precio: 2500,
    descripcion: "",
    cantidad : 1,
    tags : "stout"
  },
  {
    id: 10,
    img: "assets/img/blue.png",
    nombre: "Cerveza Blue Point Toasted Lager Botella 330ml",
    precio: 1500,
    descripcion: "",
    cantidad : 1,
    tags : "ale"
  },
  {
    id: 11,
    img: "assets/img/kona.png",
    nombre: "Cerveza Kona Big Wave Botella 355ml",
    precio: 1590,
    descripcion: "",
    cantidad : 1,
    tags : "ale"
  },
  {
    id: 12,
    img: "assets/img/stella.png",
    nombre: "Pack 6 Copas Stella 330cc",
    precio: 16900,
    descripcion: "",
    cantidad : 1,
    tags : "ale"
  }

]

  constructor(private carroService:CarroService, private router: Router) { }

  ngOnInit() {
    this.usuario = localStorage.getItem('usuarioActual');
  }

  public agregarCarro(product:IItem)
  {
    Swal.fire('Agregado!', `El producto ${product.nombre} Fue agregado con Exito!`,'success');
    this.carroService.cargarCarro(product);
  }

  busquedaClave(){
    let pos = [];
    for(let i=0;i<this.listarProductos.length;i++){
      if(this.listarProductos[i].tags.search(this.clave.value) == -1){
        pos.push(this.listarProductos[i].id);
      }
      else{
        console.log('Encontrado');
      }
    }
    for(let j=0;j<pos.length;j++){
      for(let i=0;i<this.listarProductos.length;i++){
        if(pos[j]==this.listarProductos[i].id){
          this.listarProductos.splice(i,1);
        }
      }
    }
    
  }

  quitarBusqueda(){
    this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
    this.router.navigate(["productos"]));
  }

}
