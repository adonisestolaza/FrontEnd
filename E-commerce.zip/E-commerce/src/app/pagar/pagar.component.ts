import { Component, OnInit } from '@angular/core';
import { CarroService } from '../services/carro.service';
import { IItem } from '../interfaces/item.interface';
import Swal from 'sweetalert2';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pagar',
  templateUrl: './pagar.component.html',
  styleUrls: ['./pagar.component.css']
})
export class PagarComponent implements OnInit {

  public items: Array<IItem>
  public totalPrecio:number = 0;
  public totalCantidad:number = 0;
  usuario:string;
  formularioPago: FormGroup;
  datos:string;
  pagoitems:any[]=[];

  paises = ['Chile','Argetina','Brasil'];
  regiones = ['Rm','Los lagos','Coquimbo'];
  comunas = ['San Bernardo','Santiago','Buin'];


  constructor(private carroService:CarroService, private router: Router) { }



  ngOnInit() {

    this.carroService.datosActualesCarro.subscribe(p =>{
      if(p)
      {
        this.items = p;
        this.totalCantidad = p.length;
        this.totalPrecio = p.reduce((sum, pr) => sum + (pr.precio * pr.cantidad), 0);
         p.forEach(p =>{
          this.pagoitems.push(p);
        });
      }
    });

    this.usuario = localStorage.getItem('usuarioActual');

    this.formularioPago = new FormGroup({
      nombre: new FormControl('' , [Validators.required, Validators.minLength(5), Validators.maxLength(10)]),
      apellido: new FormControl('' , [Validators.required, Validators.minLength(5), Validators.maxLength(10)]),
      email: new FormControl(''),
      codigo: new FormControl('' , [Validators.required, Validators.minLength(5), Validators.maxLength(10), Validators.pattern('[0-9]*')]),
      direccion: new FormControl('' , [Validators.required, Validators.minLength(5), Validators.maxLength(15)]),
      pais: new FormControl('' , [Validators.required]),
      region: new FormControl('' , [Validators.required]),
      comuna: new FormControl('' , [Validators.required]),
      pago: new FormControl('' , [Validators.required]),
      nombreTarjeta: new FormControl('' , [Validators.required, Validators.minLength(20), Validators.maxLength(50)]),
      numTarjeta: new FormControl('' , [Validators.required, Validators.minLength(16), Validators.maxLength(16), Validators.pattern('[0-9]*')]),
      mesTarjeta: new FormControl('' , [Validators.required]),
      annoTarjeta: new FormControl('' , [Validators.required]),
      codTarjeta: new FormControl('' , [Validators.required, Validators.minLength(3), Validators.maxLength(3), Validators.pattern('[0-9]*')]),
      });
  }

  public remove(producto:IItem)
  {
    this.carroService.quitarElemento(producto);
  }

  submit(){
    if(this.formularioPago.valid){
      Swal.fire('Correcto!','Tu compra se ha validado correctamente','success');
      this.carroService.generarPago(this.formularioPago.value);
      this.router.navigate(['boleta'])
    }else{
      console.log('No validado');
    }
  }


}
