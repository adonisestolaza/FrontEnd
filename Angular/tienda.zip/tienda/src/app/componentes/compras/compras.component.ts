import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-compras',
  templateUrl: './compras.component.html',
  styleUrls: ['./compras.component.css']
})
export class ComprasComponent implements OnInit {

  ngOnInit(): void {

  }
    total!: number;
 
  productos = [{ codigo: '123', nombre: 'Bebida', precio:  1200, cantidad: 2
  }];

  formularioProducto = new FormGroup({
    codigo: new FormControl('',[Validators.required, Validators.minLength(3)]),
    nombre: new FormControl('',[Validators.required, Validators.minLength(3)]),
    precio: new FormControl('',[Validators.required, Validators.minLength(3)]),
    cantidad: new FormControl('',[Validators.required, Validators.minLength(3)])
    });


    ingresar(){
      this.productos.forEach( p =>{
        if(p.codigo === this.formularioProducto.value.codigo){
          Swal.fire(
            'Error al agregar',
            'El producto ya existe!',
            'error'
          )
        }else{
          Swal.fire(
            'Bien!',
            'El producto fue agregado correctamente!',
            'success'
          )
        this.productos.push(this.formularioProducto.value);
        }
      }
      );
    }


    eliminar(codigo: string){

      Swal.fire({
        title: 'Estas seguro?',
        text: "el producto se eliminara de tu compras!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si, Eliminarlo!'
      }).then((result) => {
        if (result.isConfirmed) {
          Swal.fire(
            'Eliminado!',
            'El producto ha sido eliminado.',
            'success'
          )

          this.productos = this.productos.filter(p => p.codigo != codigo);
        }
      })
    }

    actualizar(codigo: string, nombre:string, precio:number, cantidad:number){

      console.log('la cantidad' + cantidad);
      
      this.productos = this.productos.map(pr =>{
        if(pr.codigo == codigo){
          pr.nombre = nombre;
          pr.precio = precio;
          pr.cantidad = cantidad;
        }
        return pr;
      });

      let producto = this.productos.find(p => p.codigo === codigo);
       console.log(producto);

    }

    comprar(){

      Swal.fire(
        'Comprado!',
        'Se emitio su boleta!',
        'success'
      )  

        this.productos.forEach(p => {

          var subtotal;
          
          subtotal = p.cantidad*p.precio;
          this.total = subtotal;
          
        });
       

        console.log(this.total);
        

    }


}
